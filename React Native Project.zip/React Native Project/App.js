import React, { useState } from "react";
import { SafeAreaView, StyleSheet, Text, View, Dimensions, Image, TouchableOpacity } from "react-native";
import { Picker } from "@react-native-picker/picker";

export default function App() {
  const [selectedDog, setSelectedDog] = useState("");
  const [selectedDogHours, setSelectedDogHours] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [selectedServiceHours, setSelectedServiceHours] = useState("");
  const [totalCost, setTotalCost] = useState(null);

  // Helper to extract price from string like "Piper - $12"
  const getPrice = (item) => {
    if (!item) return 0;
    const match = item.match(/\$(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  };

  const calculateTotal = () => {
    const dogPrice = getPrice(selectedDog);
    const dogHours = parseInt(selectedDogHours, 10) || 0;

    const servicePrice = getPrice(selectedService);
    const serviceHours = parseInt(selectedServiceHours, 10) || 0;

    const total = dogPrice * dogHours + servicePrice * serviceHours;
    setTotalCost(total);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Sigma Dog Care System (SDCS)</Text>

      <Image
        source={{
          uri: "https://res.cloudinary.com/doiq3nkso/image/upload/v1747843569/public_upload/lj6f9cj4zqujwexpyjkr.png",
        }}
        style={styles.logo}
        resizeMode="contain"
      />

      <Text style={styles.sectionTitle}>Select Dog & Hours</Text>
      <View style={styles.rowContainer}>
        <View style={styles.pickerBox}>
          <Picker
            selectedValue={selectedDog}
            style={styles.picker}
            onValueChange={(itemValue) => setSelectedDog(itemValue)}
          >
            {selectedDog === "" && <Picker.Item label="Select a dog" value="" />}
            <Picker.Item label="Piper - $12" value="Piper - $12" />
            <Picker.Item label="Rufus - $15" value="Rufus - $15" />
            <Picker.Item label="Max - $12" value="Max - $12" />
            <Picker.Item label="Miles - $18" value="Miles - $18" />
            <Picker.Item label="Jake - $22" value="Jake - $22" />
          </Picker>
        </View>

        <View style={styles.pickerBox}>
          <Picker
            selectedValue={selectedDogHours}
            style={styles.picker}
            onValueChange={(itemValue) => setSelectedDogHours(itemValue)}
          >
            {selectedDogHours === "" && <Picker.Item label="Hours of care" value="" />}
            <Picker.Item label="1" value="1" />
            <Picker.Item label="2" value="2" />
            <Picker.Item label="3" value="3" />
            <Picker.Item label="4" value="4" />
            <Picker.Item label="5" value="5" />
          </Picker>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Select Service & Hours</Text>
      <View style={styles.rowContainer}>
        <View style={styles.pickerBox}>
          <Picker
            selectedValue={selectedService}
            style={styles.picker}
            onValueChange={(itemValue) => setSelectedService(itemValue)}
          >
            {selectedService === "" && <Picker.Item label="Select a service" value="" />}
            <Picker.Item label="Grooming - $20" value="Grooming - $20" />
            <Picker.Item label="Walking - $10" value="Walking - $10" />
            <Picker.Item label="Dog Training - $30" value="Dog Training - $30" />
            <Picker.Item label="Vet - $30" value="Vet - $30" />
            <Picker.Item label="Daycare - $25" value="Daycare - $25" />
          </Picker>
        </View>

        <View style={styles.pickerBox}>
          <Picker
            selectedValue={selectedServiceHours}
            style={styles.picker}
            onValueChange={(itemValue) => setSelectedServiceHours(itemValue)}
          >
            {selectedServiceHours === "" && <Picker.Item label="Hours of care" value="" />}
            <Picker.Item label="1" value="1" />
            <Picker.Item label="2" value="2" />
            <Picker.Item label="3" value="3" />
            <Picker.Item label="4" value="4" />
            <Picker.Item label="5" value="5" />
          </Picker>
        </View>
      </View>

      {/* Calculate Button */}
      <TouchableOpacity style={styles.button} onPress={calculateTotal}>
        <Text style={styles.buttonText}>Calculate</Text>
      </TouchableOpacity>

      {/* Total Cost Display */}
      {totalCost !== null && (
        <Text style={styles.totalCost}>Total Cost: $ {totalCost}</Text>
      )}

      <View style={styles.footer}>
        <Text style={styles.credit}>App developed by Foth, Andrew, Elsa, Thomas, Tayseer</Text>
      </View>
    </SafeAreaView>
  );
}

const screenWidth = Dimensions.get("window").width;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffcc",
    paddingTop: 40,
    alignItems: "center",
  },
  heading: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#333333",
    textAlign: "center",
  },
  logo: {
    width: 200,
    height: 200,
    marginVertical: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    alignSelf: "flex-start",
    marginLeft: 10,
    marginTop: 20,
    marginBottom: 5,
    color: "#222",
  },
  rowContainer: {
    flexDirection: "row",
    width: screenWidth,
    alignSelf: "center",
  },
  pickerBox: {
    width: screenWidth / 2,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  picker: {
    height: 40,
    width: "100%",
  },
  button: {
    marginTop: 25,
    backgroundColor: "#4CAF50",
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 8,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  totalCost: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  footer: {
    position: "absolute",
    bottom: 20,
  },
  credit: {
    fontSize: 14,
    fontStyle: "italic",
    color: "#666",
  },
});
